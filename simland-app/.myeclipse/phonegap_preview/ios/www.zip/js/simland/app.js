var app = {
	//servicerURL: "http://192.168.253.3:8080/simland-app-service/",
	servicerURL: "http://192.168.1.27:8080/simland-app-service/",
	initialize : function() {
	}
}


app.initialize();